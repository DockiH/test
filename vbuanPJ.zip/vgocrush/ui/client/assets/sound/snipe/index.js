
import Sound from 'util/sounds'

export const SNIPE_SOUNDS = [
  new Sound(require('./1.mp3')),
  new Sound(require('./2.mp3')),
  new Sound(require('./3.mp3')),
  new Sound(require('./4.mp3'))
]
