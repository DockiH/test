
export const SET_PENDING_OFFERS = 'client/reducers/pendingOffers/SET_PENDING_OFFERS'
