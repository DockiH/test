

import { createAction } from 'redux-actions'
import { SET_PENDING_OFFERS } from './constants'

export const setPendingOffers = createAction(SET_PENDING_OFFERS)
