
export const SET_VALUE = 'client/reducers/server/SET_VALUE'
