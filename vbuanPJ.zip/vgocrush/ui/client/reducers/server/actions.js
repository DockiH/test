

import { createAction } from 'redux-actions'
import { SET_VALUE } from './constants'

export const setValue = createAction(SET_VALUE)
export const setValues = createAction(SET_VALUE)
