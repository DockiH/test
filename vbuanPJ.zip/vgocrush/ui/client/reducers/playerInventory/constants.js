
export const SET_PLAYER_INVENTORY = 'client/reducers/playerInventory/SET_PLAYER_INVENTORY'
