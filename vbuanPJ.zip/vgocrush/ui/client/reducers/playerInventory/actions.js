

import { createAction } from 'redux-actions'
import { SET_PLAYER_INVENTORY } from './constants'

export const setPlayerInventory = createAction(SET_PLAYER_INVENTORY)
