
export const SET_TRADE_OFFERS = 'client/reducers/tradeOffers/SET_TRADE_OFFERS'
