

import { createAction } from 'redux-actions'
import { SET_TRADE_OFFERS } from './constants'

export const setTradeOffers = createAction(SET_TRADE_OFFERS)
