
export const SET_TOGGLES = 'client/reducers/toggles/SET_TOGGLES'

export const CRASH_DISABLED_MESSAGE = 'Crash is currently paused, be back soon!'
export const CRASH_DISABLED_NEXT_MESSAGE = 'Crash will be paused next round for an update!'
