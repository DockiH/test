

import { createAction } from 'redux-actions'
import { SET_TOGGLES } from './constants'

export const setToggles = createAction(SET_TOGGLES)
