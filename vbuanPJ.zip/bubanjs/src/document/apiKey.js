
import r from '../lib/database'

const ApiKeys = r.table('ApiKeys')

export default ApiKeys
