
import r from '../lib/database'

const Items = r.table('Items')
export default Items

export const ItemSales = r.table('ItemSales')
export const ItemListings = r.table('ItemListings')
