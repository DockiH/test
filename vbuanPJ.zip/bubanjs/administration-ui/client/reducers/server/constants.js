
export const SET_SERVER_TOKEN = 'client/reducers/server/SET_SERVER_TOKEN'
