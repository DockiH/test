
import { createAction } from 'redux-actions'
import { SET_SERVER_TOKEN } from './constants'

export const setServerToken = createAction(SET_SERVER_TOKEN)
