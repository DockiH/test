
export const SET_CURRENT_USER = 'client/reducers/user/SET_CURRENT_USER'
export const UPDATE_CURRENT_USER = 'client/reducers/user/UPDATE_CURRENT_USER'
