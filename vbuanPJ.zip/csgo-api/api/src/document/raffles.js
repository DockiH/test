
import r from '../lib/database'

const Raffles = r.table('Raffles')
export default Raffles

export const RaffleEntries = r.table('RaffleEntries')
