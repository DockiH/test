
import r from '../lib/database'

const Promotions = r.table('Promotions')
export default Promotions
