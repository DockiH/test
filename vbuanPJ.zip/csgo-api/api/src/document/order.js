
import r from '../lib/database'

const Order = r.table('Order')
export default Order
