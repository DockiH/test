
import r from '../lib/database'

const FAQ = r.table('FAQ')
export default FAQ
