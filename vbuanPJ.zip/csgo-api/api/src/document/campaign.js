
import r from '../lib/database'

const Campaign = r.table('Campaign')
export default Campaign
