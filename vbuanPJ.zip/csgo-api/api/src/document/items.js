
import r from '../lib/database'
import co from 'co'

const AvailableItems = r.table('AvailableItems')
export default AvailableItems
