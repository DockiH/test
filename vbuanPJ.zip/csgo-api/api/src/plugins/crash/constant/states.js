
export const StateNotStarted    = 'NotStarted'
export const StateStarting      = 'Starting'
export const StateInProgress    = 'InProgress'
export const StateOver          = 'Over'
export const StateBlocking      = 'Blocking'
