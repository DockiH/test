
import r from 'lib/database'

const ChatHistory = r.table('ChatHistory')
export default ChatHistory
