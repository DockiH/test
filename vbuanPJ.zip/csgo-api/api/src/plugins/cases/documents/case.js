
import r from 'lib/database'

const Case = r.table('Case')
export default Case

export const CaseItems = r.table('CaseItems')
