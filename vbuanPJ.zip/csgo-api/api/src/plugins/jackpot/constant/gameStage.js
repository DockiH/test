
export const stageWaitingJoin = 'WaitingJoin'
export const stageStarting = 'Starting'
export const stageInProgress = 'InProgress'
export const stageOver = 'Over'

export const betStages = [
  stageWaitingJoin,
  stageStarting
]
