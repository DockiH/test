
export const stateActive = 'Active'
export const stateOver = 'Over'
