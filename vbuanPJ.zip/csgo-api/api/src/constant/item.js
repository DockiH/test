
export const ITEM_WEAR = [
  'Battle-Scarred', 'Well-Worn', 'Field-Tested', 'Minimal Wear', 'Factory New', ''
]

export const ITEM_SHORT_WEAR = {
  bs: 'Battle-Scarred',
  ww: 'Well-Worn',
  ft: 'Field-Tested',
  mw: 'Minimal Wear',
  fn: 'Factory New'
}
